module.exports = function(app, db) {

    app.post('/login', function(req, res) {
         loginUser(db,req.body.email,req.body.password, res)
    })
};

function loginUser(db, email,password, res){
    var query = { email: email, password: password };
    db.collection("users").find(query).toArray(function(err, result) {
        if (err) throw err;
        if(result.length>0){
            var ret = {  error: "0", userid : result[0].userid, role: result[0].role}

            res.send(ret)
        }else{
            res.send("{\"error\":\"1\",\"errorMsg\":\"User Not Found or invalid Details\"}")
        }
    });
}